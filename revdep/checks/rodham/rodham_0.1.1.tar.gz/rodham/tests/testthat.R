library(testthat)
library(rodham)

test_check("rodham")
